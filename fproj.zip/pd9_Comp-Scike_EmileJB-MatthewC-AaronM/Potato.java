public class Potato extends Tower {

    public Potato() {
	super(null,3,1,1,0,100,Images.potato());
	id = 5;
	maxUpgrades = new int[]{3,1,2,0};
    }
}
